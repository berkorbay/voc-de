from __future__ import annotations

from ._output import output_args, suspend_display

__all__ = (
    "output_args",
    "suspend_display",
)
